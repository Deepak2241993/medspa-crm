<div class="width-100px text-end">
    {{ getCurrencyAmount($row->final_amount, true) }}
</div>
