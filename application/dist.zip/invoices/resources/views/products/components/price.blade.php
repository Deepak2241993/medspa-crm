<div class="d-flex justify-content-end width-150px">
    {{getCurrencyAmount($row->unit_price,true)}}
</div>
