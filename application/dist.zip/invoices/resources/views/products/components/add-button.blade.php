<a type="button" class="btn btn-primary" href="{{ route('products.create')}}">
    {{__('messages.product.add_product')}}
</a>
