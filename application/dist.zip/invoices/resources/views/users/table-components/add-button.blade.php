<a type="button" class="btn btn-primary" href="{{ route('users.create')}}">
    {{__('messages.add_admin')}}
</a>

