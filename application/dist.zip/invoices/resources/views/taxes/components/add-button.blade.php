<button type="button" class="btn btn-primary addTax">
    {{ __('messages.tax.add_tax') }}
</button>
