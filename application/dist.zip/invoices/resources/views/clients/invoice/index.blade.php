    <div class="row">
        <div class="col-lg-12 ">
            <livewire:client-detail-invoice-table clientId="{{ $client->id }}" />
        </div>
    </div>

