<div class="row">
    <div class="col-lg-12 ">
        <livewire:client-detail-quote-table clientId="{{ $client->id }}"/>
    </div>
</div>

