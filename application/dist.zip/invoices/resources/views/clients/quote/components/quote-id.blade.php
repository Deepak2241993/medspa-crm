<a href="{{ route('quotes.show',$row->id) }}"
   class="badge bg-light-primary text-decoration-none">{{$row->quote_id}}</a>
