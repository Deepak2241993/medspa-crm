<a type="button" class="btn btn-primary" href="{{ route('clients.create')}}">
    {{__('messages.client.add_client')}}
</a>
