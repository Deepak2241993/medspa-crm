<div class="width-100px text-end">
    {{ getInvoiceCurrencyAmount($row->final_amount, $row->currency_id, true) }}
</div>
