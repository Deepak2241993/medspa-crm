<button type="button" class="btn btn-primary addCategory">
    {{ __('messages.category.add_category') }}
</button>
