<a href="{{route('client.quotes.show', $row->id)}}"
   class="badge bg-light-info text-decoration-none">{{$row->quote_id}}</a>
