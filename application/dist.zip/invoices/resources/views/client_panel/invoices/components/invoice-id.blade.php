<a href="{{route('client.invoices.show', $row->id)}}" class="badge bg-light-info text-decoration-none">{{$row->invoice_id}}</a>
