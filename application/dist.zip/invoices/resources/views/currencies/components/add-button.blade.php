<button type="button" class="btn btn-primary addCurrency">
    {{ __('messages.currency.add_currency') }}
</button>
