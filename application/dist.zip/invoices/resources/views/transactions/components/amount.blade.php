<div class="width-100px text-end">
    {{ getInvoiceCurrencyAmount($row->amount, $row->invoice->currency_id, true) }}
</div>
