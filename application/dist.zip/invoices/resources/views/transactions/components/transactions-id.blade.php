{{ is_null($row->transaction_id) ?  __('messages.common.n/a') : $row->transaction_id}}
