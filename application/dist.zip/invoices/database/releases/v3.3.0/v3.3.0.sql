ALTER TABLE `users`
    ADD `dark_mode` TINYINT(1) NOT NULL DEFAULT '0' AFTER `language`;
