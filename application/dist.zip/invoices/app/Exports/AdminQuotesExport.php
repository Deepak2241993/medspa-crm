<?php

namespace App\Exports;

use App\Models\Quote;
use Illuminate\Contracts\View\View;
use Maatwebsite\Excel\Concerns\FromView;

class AdminQuotesExport implements FromView
{
    /**
     * @return View
     */
    public function view(): View
    {
        $quotes = Quote::with('client.user')->orderBy('created_at','desc')->get();

        return view('excel.admin_quotes_excel', compact('quotes'));
    }
}
